# Outfity — статический прототип (осень)

Мини‑приложение для сборки осенних образов из PNG‑слоёв (2D paper‑doll стиль).

## Структура
```
outfity/
  index.html
  styles.css
  script.js
  manifest.json
  assets/
    avatars/
      female/avatar_female_1.png
      male/avatar_male_1.png
    clothes/
      autumn/
        tops/*.png
        bottoms/*.png
        outerwear/*.png
        shoes/*.png
        accessories/*.png
```

## Запуск
Просто открой `index.html` в браузере (двойной клик). Никакой сборки не требуется.

## Деплой
- **GitHub Pages**: Settings → Pages → Deploy from branch → `main` → `/root`.
- **Netlify**: New site from Git → подключи репозиторий → Build command: _none_ → Publish directory: `/`.

## Добавить новые вещи
1. Положи PNG в нужную папку внутри `assets/clothes/autumn/...`.
2. Добавь относительный путь в `manifest.json` (в соответствующий раздел).
3. Обнови страницу в браузере.
