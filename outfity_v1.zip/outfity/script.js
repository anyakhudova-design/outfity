async function loadManifest() {
  const res = await fetch('manifest.json');
  return await res.json();
}

function makeChoices(container, items, onPick) {
  const el = document.getElementById(container);
  el.innerHTML = '';
  items.forEach((src) => {
    const btn = document.createElement('button');
    btn.className = 'choice';
    const short = src.split('/').pop().replace('.png','');
    btn.textContent = short;
    btn.onclick = () => {
      [...el.children].forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      onPick(src);
    };
    el.appendChild(btn);
  });
}

function setImg(id, src) {
  const img = document.getElementById(id);
  img.src = src || '';
  img.style.display = src ? 'block' : 'none';
}

function initReset() {
  document.getElementById('reset').onclick = () => {
    ['outerwear','top','bottom','shoes','accessory'].forEach(k => setImg(k, ''));
  };
}

loadManifest().then((mf) => {
  // avatars (female by default)
  const avatars = [...(mf.avatars.female || []), ...(mf.avatars.male || [])];
  makeChoices('avatar-choices', avatars, (src) => setImg('avatar', src));

  // set default avatar
  if (avatars[0]) setImg('avatar', avatars[0]);

  const A = mf.clothes.autumn;
  makeChoices('top-choices', A.tops, (src) => setImg('top', src));
  makeChoices('bottom-choices', A.bottoms, (src) => setImg('bottom', src));
  makeChoices('outerwear-choices', A.outerwear, (src) => setImg('outerwear', src));
  makeChoices('shoes-choices', A.shoes, (src) => setImg('shoes', src));
  makeChoices('accessory-choices', A.accessories, (src) => setImg('accessory', src));

  initReset();
});
